<div align="center">
  <h1>Attendence-System</h1>
</div>




## Getting Started

1. Fork the repository
2. Clone the repository



3. Open the folder containing the cloned repository

4.Download dependencies
Go inside ./N_Attendance_M/

```sh
Run npm install 
```

Go inside N_Attendance_M/frontend

```sh
Run npm install
```

To start the project-backend on localhost Go inside ./N_Attendance_M/

```sh
Run nodemon
```

To start the project-frontend on localhost Go inside ./N_Attendance_M/backend

```sh
Run npm start




